# Spring MVC vs WebFlux

This project demonstrates the difference between Spring MVC (synchronous/blocking) and Spring WebFlux (asynchronous/non-blocking) approaches.

## Run Instructions

1. **Build and Run**: Use an IDE like IntelliJ IDEA or run `./gradlew bootRun`.
2. **Endpoints**:
   - Spring MVC: [http://localhost:8080/mvc/hello](http://localhost:8080/mvc/hello)
   - Spring WebFlux: [http://localhost:8081/webflux/hello](http://localhost:8081/webflux/hello)
3. **Performance Testing**: Use `wrk` for load testing.

## Expected Results

| Metric                | Spring MVC (8080) | Spring WebFlux (8081) |
|-----------------------|-------------------|-----------------------|
| Average Latency       | ~150ms           | ~50ms                |
| Throughput            | ~1200 req/sec    | ~4500 req/sec        |
| Max Latency           | ~500ms           | ~150ms               |
